#ifndef NODE_H
#define NODE_H

// Node structure definition
typedef struct Node {
    int data;
    struct Node* next;
} Node;

#endif