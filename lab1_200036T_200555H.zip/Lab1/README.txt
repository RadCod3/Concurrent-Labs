To Run the Program:
Run the following commands in the terminal:

1. make
2. ./linkedlist.exe

The program will print results for all the scenarios for a given case to the console. 
It will show Average Time, Std.Deviation, Minimum Number of Repetitions Required for a single scenario.

To adjust Number of Iterations, Fraction of Member Operations, Insert Operations and Delete Operations check line number 11 onwards in main.c file.

Script to draw plots from the collected data is available in plots.py. 
